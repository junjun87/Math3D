"""
立体几何 SymPy 精确计算内核 (参照 edulab geometry_kernel.py)。

核心设计原则：所有数值（最终答案、分步中间值、3D 坐标、高亮标注）
全部来自同一次 sympy 计算调用，确保数据一致性。

支持的问题类型：
- line_plane_angle: 线面角
- dihedral_angle: 二面角
- skew_line_angle: 异面直线夹角
- point_plane_distance: 点面距离
- volume: 体积
- surface_area: 表面积
"""

from __future__ import annotations
import sympy as sp
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ComputationResult:
    """计算内核的完整输出。"""
    subject: str = "solid_geometry"
    body_type: str = "cube"
    problem_type: str = ""
    answer: dict = field(default_factory=dict)       # { latex, exact, numeric_approx }
    steps: list[dict] = field(default_factory=list)  # 分步解析
    model_3d: dict = field(default_factory=dict)     # 3D 渲染数据


class SolidGeometryKernel:
    """
    立体几何计算内核。

    使用坐标法 + 向量法统一求解各类立体几何问题。
    所有计算使用 sympy 符号数学，确保精确值。
    """

    def __init__(self):
        self.x, self.y, self.z = sp.symbols("x y z", real=True)

    def compute(self, problem: dict) -> ComputationResult:
        """根据结构化题目执行计算。"""
        body_type = problem.get("body_type", "cube")
        problem_type = problem.get("target", {}).get("type", "line_plane_angle")

        # 获取参数
        params = problem.get("given", {})
        edge_length = params.get("edge_length", 2)

        result = ComputationResult(
            body_type=body_type,
            problem_type=problem_type,
        )

        if body_type == "cube":
            return self._compute_cube(problem, result)

        result.steps = [{
            "step_number": 1,
            "title": "暂不支持",
            "description": f"几何体类型 '{body_type}' 暂未实现",
            "formula": "",
            "result": "",
        }]
        result.answer = {"latex": "N/A", "exact": "N/A"}
        return result

    # ========== 正方体 ==========

    def _compute_cube(self, problem: dict, result: ComputationResult) -> ComputationResult:
        """正方体相关问题计算。"""
        a = problem.get("given", {}).get("edge_length", 2)
        a = sp.sympify(a)

        # 建立顶点坐标
        vertices = self._cube_coordinates(a)
        result.model_3d = self._build_3d_model("cube", vertices, a)

        target = problem.get("target", {})
        problem_type = target.get("type", "line_plane_angle")

        if problem_type == "line_plane_angle":
            return self._cube_line_plane_angle(vertices, target, result, a)
        elif problem_type == "dihedral_angle":
            return self._cube_dihedral_angle(vertices, target, result, a)
        elif problem_type == "skew_line_angle":
            return self._cube_skew_line_angle(vertices, target, result, a)
        elif problem_type == "point_plane_distance":
            return self._cube_point_plane_distance(vertices, target, result, a)
        elif problem_type == "volume":
            return self._cube_volume(result, a)
        else:
            return self._unknown_type(result, problem_type)

    def _cube_coordinates(self, a) -> dict[str, sp.Matrix]:
        """正方体标准坐标系：A 为原点，AB 为 x 轴，AD 为 y 轴，AA1 为 z 轴。"""
        return {
            "A":  sp.Matrix([0, 0, 0]),
            "B":  sp.Matrix([a, 0, 0]),
            "C":  sp.Matrix([a, a, 0]),
            "D":  sp.Matrix([0, a, 0]),
            "A1": sp.Matrix([0, 0, a]),
            "B1": sp.Matrix([a, 0, a]),
            "C1": sp.Matrix([a, a, a]),
            "D1": sp.Matrix([0, a, a]),
        }

    # ---- 线面角 ----
    def _cube_line_plane_angle(
        self, V: dict, target: dict, result: ComputationResult, a
    ) -> ComputationResult:
        """
        求直线与平面所成角的正弦值。

        步骤：
        1. 建立坐标系，写出各点坐标
        2. 求直线的方向向量
        3. 求平面的法向量（两向量叉乘）
        4. 用公式 sinθ = |v·n| / (|v||n|) 求线面角
        """
        line_str = target.get("line", "AB1")
        plane_str = target.get("plane", "A1C1D")

        # 解析直线顶点
        v_from, v_to = self._parse_line(line_str)
        v_from_vec = V[v_from]
        v_to_vec = V[v_to]

        # 直线方向向量
        line_dir = v_to_vec - v_from_vec

        # 解析平面顶点（3点确定平面）
        plane_pts = self._parse_plane_label(plane_str)
        p1, p2, p3 = V[plane_pts[0]], V[plane_pts[1]], V[plane_pts[2]]

        # 平面法向量 = (p2-p1) × (p3-p1)
        normal = (p2 - p1).cross(p3 - p1)

        # 线面角公式: sinθ = |line·normal| / (|line| * |normal|)
        dot_val = sp.Abs(line_dir.dot(normal))
        mag_line = sp.sqrt(line_dir.dot(line_dir))
        mag_normal = sp.sqrt(normal.dot(normal))
        sin_theta = sp.simplify(dot_val / (mag_line * mag_normal))

        # 角度值
        theta = sp.asin(sin_theta)

        steps = [
            {
                "step_number": 1,
                "title": "建立坐标系",
                "description": f"以 A 为原点建立空间直角坐标系，棱长为 {sp.latex(a)}",
                "formula": "A(0,0,0), B(a,0,0), C(a,a,0), D(0,a,0), "
                          "A_1(0,0,a), B_1(a,0,a), C_1(a,a,a), D_1(0,a,a)",
                "result": "",
            },
            {
                "step_number": 2,
                "title": "求直线的方向向量",
                "description": f"直线 {line_str} 的方向向量",
                "formula": (rf"\overrightarrow{{{line_str}}} = "
                           rf"{sp.latex(v_to_vec)} - {sp.latex(v_from_vec)} "
                           rf"= {sp.latex(line_dir)}"),
                "result": "",
            },
            {
                "step_number": 3,
                "title": "求平面的法向量",
                "description": f"平面 {plane_str} 的法向量",
                "formula": (rf"\vec{{n}} = ({sp.latex(p2 - p1)}) \times "
                           rf"({sp.latex(p3 - p1)}) = {sp.latex(normal)}"),
                "result": "",
            },
            {
                "step_number": 4,
                "title": "计算线面角",
                "description": f"直线 {line_str} 与平面 {plane_str} 所成角的正弦值",
                "formula": (rf"\sin\theta = \frac{{|\overrightarrow{{{line_str}}}\cdot\vec{{n}}|}}"
                           rf"{{|\overrightarrow{{{line_str}}}|\cdot|\vec{{n}}|}} "
                           rf"= {sp.latex(sin_theta)}"),
                "result": rf"\theta = \arcsin({sp.latex(sin_theta)}) = {sp.latex(theta)}",
            },
        ]

        result.steps = steps
        result.answer = {
            "latex": sp.latex(sin_theta),
            "exact": str(sin_theta),
            "numeric": float(sin_theta.evalf()),
            "angle_latex": sp.latex(theta),
        }

        return result

    # ---- 二面角 ----
    def _cube_dihedral_angle(
        self, V: dict, target: dict, result: ComputationResult, a
    ) -> ComputationResult:
        """求二面角。两个平面的法向量夹角即为二面角。"""
        plane1_str = target.get("plane1", "A1BD")
        plane2_str = target.get("plane2", "C1BD")

        pts1 = self._parse_plane_label(plane1_str)
        pts2 = self._parse_plane_label(plane2_str)

        # 平面法向量
        n1 = (V[pts1[1]] - V[pts1[0]]).cross(V[pts1[2]] - V[pts1[0]])
        n2 = (V[pts2[1]] - V[pts2[0]]).cross(V[pts2[2]] - V[pts2[0]])

        # cos(二面角) = |n1·n2| / (|n1||n2|)
        cos_angle = sp.Abs(n1.dot(n2)) / (sp.sqrt(n1.dot(n1)) * sp.sqrt(n2.dot(n2)))
        cos_angle = sp.simplify(cos_angle)

        steps = [
            {
                "step_number": 1,
                "title": "建立坐标系",
                "description": f"以 A 为原点建立空间直角坐标系，棱长为 {sp.latex(a)}",
                "formula": "",
                "result": "",
            },
            {
                "step_number": 2,
                "title": "求平面法向量",
                "description": f"分别求平面 {plane1_str} 和 {plane2_str} 的法向量",
                "formula": (rf"\vec{{n}}_1 = {sp.latex(n1)}, \quad "
                           rf"\vec{{n}}_2 = {sp.latex(n2)}"),
                "result": "",
            },
            {
                "step_number": 3,
                "title": "计算二面角",
                "description": f"平面 {plane1_str} 与 {plane2_str} 的二面角",
                "formula": (rf"\cos\theta = \frac{{|\vec{{n}}_1 \cdot \vec{{n}}_2|}}"
                           rf"{{|\vec{{n}}_1| \cdot |\vec{{n}}_2|}} = "
                           rf"{sp.latex(cos_angle)}"),
                "result": rf"\theta = \arccos({sp.latex(cos_angle)})",
            },
        ]

        result.steps = steps
        result.answer = {
            "latex": sp.latex(cos_angle),
            "exact": str(cos_angle),
            "numeric": float(cos_angle.evalf()),
        }

        return result

    # ---- 异面直线夹角 ----
    def _cube_skew_line_angle(
        self, V: dict, target: dict, result: ComputationResult, a
    ) -> ComputationResult:
        """求异面直线夹角。"""
        line1_str = target.get("line1", "A1B")
        line2_str = target.get("line2", "C1D")

        v1 = V[self._parse_line(line1_str)[1]] - V[self._parse_line(line1_str)[0]]
        v2 = V[self._parse_line(line2_str)[1]] - V[self._parse_line(line2_str)[0]]

        cos_angle = sp.Abs(v1.dot(v2)) / (sp.sqrt(v1.dot(v1)) * sp.sqrt(v2.dot(v2)))
        cos_angle = sp.simplify(cos_angle)

        steps = [
            {
                "step_number": 1,
                "title": "建立坐标系",
                "description": f"以 A 为原点建立空间直角坐标系，棱长为 {sp.latex(a)}",
                "formula": "",
                "result": "",
            },
            {
                "step_number": 2,
                "title": "求方向向量",
                "description": f"分别求 {line1_str} 和 {line2_str} 的方向向量",
                "formula": (rf"\overrightarrow{{{line1_str}}} = {sp.latex(v1)}, \quad "
                           rf"\overrightarrow{{{line2_str}}} = {sp.latex(v2)}"),
                "result": "",
            },
            {
                "step_number": 3,
                "title": "计算夹角",
                "description": f"异面直线 {line1_str} 与 {line2_str} 的夹角",
                "formula": (rf"\cos\theta = \frac{{|\overrightarrow{{{line1_str}}}"
                           rf"\cdot\overrightarrow{{{line2_str}}}|}}"
                           rf"{{|\overrightarrow{{{line1_str}}}|\cdot"
                           rf"|\overrightarrow{{{line2_str}}}|}} = "
                           rf"{sp.latex(cos_angle)}"),
                "result": rf"\theta = \arccos({sp.latex(cos_angle)})",
            },
        ]

        result.steps = steps
        result.answer = {
            "latex": sp.latex(cos_angle),
            "exact": str(cos_angle),
            "numeric": float(cos_angle.evalf()),
        }

        return result

    # ---- 点面距离 ----
    def _cube_point_plane_distance(
        self, V: dict, target: dict, result: ComputationResult, a
    ) -> ComputationResult:
        """求点到平面的距离。"""
        point_str = target.get("point", "B1")
        plane_str = target.get("plane", "A1C1D")

        P = V[point_str]
        pts = self._parse_plane_label(plane_str)
        p0, p1, p2 = V[pts[0]], V[pts[1]], V[pts[2]]

        normal = (p1 - p0).cross(p2 - p0)
        distance = sp.Abs((P - p0).dot(normal)) / sp.sqrt(normal.dot(normal))
        distance = sp.simplify(distance)

        steps = [
            {
                "step_number": 1,
                "title": "建立坐标系",
                "description": f"以 A 为原点建立空间直角坐标系，棱长为 {sp.latex(a)}",
                "formula": "",
                "result": "",
            },
            {
                "step_number": 2,
                "title": "求平面法向量",
                "description": f"平面 {plane_str} 的法向量",
                "formula": rf"\vec{{n}} = {sp.latex(normal)}",
                "result": "",
            },
            {
                "step_number": 3,
                "title": "代入点面距离公式",
                "description": f"点 {point_str} 到平面 {plane_str} 的距离",
                "formula": (rf"d = \frac{{|\overrightarrow{{{point_str}{pts[0]}}}"
                           rf"\cdot\vec{{n}}|}}{{|\vec{{n}}|}} = "
                           rf"{sp.latex(distance)}"),
                "result": f"距离为 {sp.latex(distance)}",
            },
        ]

        result.steps = steps
        result.answer = {
            "latex": sp.latex(distance),
            "exact": str(distance),
            "numeric": float(distance.evalf()),
        }

        return result

    # ---- 体积 ----
    def _cube_volume(self, result: ComputationResult, a) -> ComputationResult:
        v = a ** 3
        result.steps = [
            {
                "step_number": 1,
                "title": "正方体体积公式",
                "description": "正方体体积 = 棱长的立方",
                "formula": rf"V = a^3 = {sp.latex(a)}^3 = {sp.latex(v)}",
                "result": f"体积为 {sp.latex(v)}",
            },
        ]
        result.answer = {
            "latex": sp.latex(v),
            "exact": str(v),
            "numeric": float(v.evalf()),
        }
        return result

    # ---- 未知类型 ----
    def _unknown_type(self, result: ComputationResult, problem_type: str) -> ComputationResult:
        result.steps = [{
            "step_number": 1,
            "title": "未知题型",
            "description": f"暂不支持的问题类型: '{problem_type}'",
            "formula": "",
            "result": "",
        }]
        result.answer = {"latex": "N/A", "exact": "N/A"}
        return result

    # ========== 辅助方法 ==========

    def _parse_line(self, line_str: str) -> tuple[str, str]:
        """解析直线标签，如 'AB1' → ('A', 'B1')"""
        if len(line_str) == 2:
            return (line_str[0], line_str[1])
        elif len(line_str) == 3:
            # 可能是 "AB1" (A→B1) 或 "A1B" (A1→B)
            if line_str[1].isdigit():
                return (line_str[:2], line_str[2])
            else:
                return (line_str[0], line_str[1:])
        elif len(line_str) == 4:
            return (line_str[:2], line_str[2:])
        return (line_str[0], line_str[-1])

    def _parse_plane_label(self, plane_str: str) -> list[str]:
        """解析平面标签，如 'A1C1D' → ['A1', 'C1', 'D']"""
        # 按数字后缀分割
        import re
        parts = re.findall(r'[A-Z]\d?', plane_str)
        return parts[:3] if len(parts) >= 3 else parts

    def _build_3d_model(
        self, body_type: str, vertices: dict[str, sp.Matrix], a
    ) -> dict:
        """构建 3D 渲染模型数据。"""
        # 将 sympy 矩阵转为 Python float 列表
        points = {}
        for label, vec in vertices.items():
            pt = [float(c.evalf()) if hasattr(c, 'evalf') else float(c) for c in vec]
            points[label] = pt

        from app.kernels.geometry.bodies import get_body_edges, get_body_faces

        edges = get_body_edges(body_type)
        faces = get_body_faces(body_type)

        return {
            "points": points,
            "edges": edges,
            "faces": faces,
            "scale": float(a),
        }

    def to_three_coords(
        self, sympy_points: dict[str, sp.Matrix], scale: float = 1.0
    ) -> dict[str, list[float]]:
        """将 sympy 坐标转换为 Three.js 可用的浮点坐标。"""
        result = {}
        for label, vec in sympy_points.items():
            result[label] = [
                float(vec[0].evalf()) / scale,
                float(vec[2].evalf()) / scale,  # y/z 交换适配 Three.js
                float(vec[1].evalf()) / scale,
            ]
        return result
